//============================================================================
// Name        : TP2.cpp
// Author      : Grupo NEO
//               Joel Perez
//               Analia Ludueña
//               Gabriela Choque
//               Veronica Leguizamon
//               Noelia Rodriguez
// Version     :
// Copyright   : Copyright  2018
// Description : Algoritmos y Programacion II - T.P. 2
//============================================================================

#include <iostream>
#include "TP2.h"

using namespace std;

int main() {
	Juego juego;
	juego.iniciarJuego();
	return 0;
}
