#ifndef TP2_H_
#define TP2_H_

#include "Consola.h"
#include "Juego.h"

#endif
