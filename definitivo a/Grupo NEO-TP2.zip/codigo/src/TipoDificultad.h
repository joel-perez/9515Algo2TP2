#ifndef TIPODIFICULTAD_H_
#define TIPODIFICULTAD_H_

enum TipoDificultad {
	FACIL = 1, INTERMEDIO = 2, DIFICIL = 3
};

#endif
