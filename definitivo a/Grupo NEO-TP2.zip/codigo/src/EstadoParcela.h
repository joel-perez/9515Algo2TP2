#ifndef ESTADOPARCELA_H_
#define ESTADOPARCELA_H_

enum EstadoParcela{
	VACIA,
	SEMBRADA,
	SECA,
	PODRIDA,
	RECUPERACION
};

#endif
